(function () {



/* Exports */
Package._define("nathantreid:static-assets");

})();
